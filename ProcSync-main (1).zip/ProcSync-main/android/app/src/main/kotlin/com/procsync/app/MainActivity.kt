package com.procsync.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
