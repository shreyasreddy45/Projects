import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';

/// This class is used in the [login_screen] screen.
class LoginModel extends Equatable {
  LoginModel();

  LoginModel copyWith() {
    return LoginModel();
  }

  @override
  List<Object?> get props => [];
}
